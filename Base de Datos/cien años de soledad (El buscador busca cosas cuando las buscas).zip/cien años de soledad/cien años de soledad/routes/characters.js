const express = require('express');
const router = express.Router();
const Character = require('../models/Character');

// Obtener todos los personajes
router.get('/', async (req, res) => {
  try {
    const characters = await Character.find()
      .populate('pareja')
      .populate('hijos');
    res.json(characters);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Obtener un personaje específico
router.get('/:id', async (req, res) => {
  try {
    const character = await Character.findById(req.params.id)
      .populate('pareja')
      .populate('hijos');
    if (!character) return res.status(404).json({ message: 'Personaje no encontrado' });
    res.json(character);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo personaje
router.post('/', async (req, res) => {
  const character = new Character({
    nombre: req.body.nombre,
    generacion: req.body.generacion,
    pareja: req.body.pareja,
    hijos: req.body.hijos
  });

  try {
    const newCharacter = await character.save();
    res.status(201).json(newCharacter);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Actualizar personaje
router.patch('/:id', async (req, res) => {
  try {
    const updatedCharacter = await Character.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate('pareja hijos');
    if (!updatedCharacter) return res.status(404).json({ message: 'Personaje no encontrado' });
    res.json(updatedCharacter);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Buscar personajes
router.get('/search/:term', async (req, res) => {
  try {
    const characters = await Character.find({
      $or: [
        { nombre: { $regex: req.params.term, $options: 'i' } },
        { generacion: isNaN(req.params.term) ? -1 : parseInt(req.params.term) }
      ]
    }).populate('pareja hijos');
    res.json(characters);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;