const express = require('express');
const router = express.Router();
const Place = require('../models/Place');

// Obtener todos los lugares
router.get('/', async (req, res) => {
  try {
    const places = await Place.find();
    res.json(places);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Obtener un lugar específico
router.get('/:id', async (req, res) => {
  try {
    const place = await Place.findById(req.params.id);
    if (!place) return res.status(404).json({ message: 'Lugar no encontrado' });
    res.json(place);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo lugar
router.post('/', async (req, res) => {
  const place = new Place({
    nombre: req.body.nombre,
    descripcion: req.body.descripcion,
    importancia: req.body.importancia
  });

  try {
    const newPlace = await place.save();
    res.status(201).json(newPlace);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Actualizar lugar
router.patch('/:id', async (req, res) => {
  try {
    const updatedPlace = await Place.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedPlace) return res.status(404).json({ message: 'Lugar no encontrado' });
    res.json(updatedPlace);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Buscar lugares
router.get('/search/:term', async (req, res) => {
  try {
    const places = await Place.find({
      $or: [
        { nombre: { $regex: req.params.term, $options: 'i' } },
        { descripcion: { $regex: req.params.term, $options: 'i' } }
      ]
    });
    res.json(places);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;