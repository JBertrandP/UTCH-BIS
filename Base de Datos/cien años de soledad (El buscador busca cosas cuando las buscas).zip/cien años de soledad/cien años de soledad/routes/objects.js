const express = require('express');
const router = express.Router();
const Object = require('../models/Object');

// Obtener todos los objetos
router.get('/', async (req, res) => {
  try {
    const objects = await Object.find().populate('dueno');
    res.json(objects);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Obtener un objeto específico
router.get('/:id', async (req, res) => {
  try {
    const object = await Object.findById(req.params.id).populate('dueno');
    if (!object) return res.status(404).json({ message: 'Objeto no encontrado' });
    res.json(object);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo objeto
router.post('/', async (req, res) => {
  const object = new Object({
    nombre: req.body.nombre,
    descripcion: req.body.descripcion,
    dueño: req.body.dueño,
    simbolismo: req.body.simbolismo
  });

  try {
    const newObject = await object.save();
    res.status(201).json(newObject);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Actualizar objeto
router.patch('/:id', async (req, res) => {
  try {
    const updatedObject = await Object.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate('dueno');
    if (!updatedObject) return res.status(404).json({ message: 'Objeto no encontrado' });
    res.json(updatedObject);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Buscar objetos
router.get('/search/:term', async (req, res) => {
  try {
    const objects = await Object.find({
      $or: [
        { nombre: { $regex: req.params.term, $options: 'i' } },
        { descripcion: { $regex: req.params.term, $options: 'i' } },
        { simbolismo: { $regex: req.params.term, $options: 'i' } }
      ]
    }).populate('dueno');
    res.json(objects);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;