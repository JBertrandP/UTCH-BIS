const express = require("express");
const router = express.Router();

const Character = require("../models/Character");
const Dream = require("../models/Dream");
const Event = require("../models/Event");
const ObjectModel = require("../models/Object");
const Place = require("../models/Place");
const Symbol = require("../models/Symbol");

// Utilidad para obtener texto minúsculo sin tildes
function normalize(text) {
  return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

router.get("/", async (req, res) => {
  const query = req.query.q;

  if (!query || !query.includes("?")) {
    return res.status(400).json({ message: "Debes escribir una pregunta válida con ?" });
  }

  const lowered = normalize(query);
  let collections = [];

  // Palabras clave para determinar qué buscar
  if (lowered.includes("signific") || lowered.includes("simbol")) {
    collections = ["symbols", "dreams"];
  } else if (lowered.includes("soñ") || lowered.includes("sueño")) {
    collections = ["dreams"];
  } else if (lowered.includes("quien") || lowered.includes("personaje")) {
    collections = ["characters"];
  } else if (lowered.includes("donde") || lowered.includes("lugar")) {
    collections = ["places", "events"];
  } else if (lowered.includes("objeto") || lowered.includes("cosa")) {
    collections = ["objects"];
  } else if (lowered.includes("evento") || lowered.includes("paso")) {
    collections = ["events"];
  } else {
    // Búsqueda general si no se detecta ninguna categoría
    collections = ["characters", "dreams", "events", "objects", "places", "symbols"];
  }

  try {
    const results = {};

    for (const col of collections) {
      let Model;
      switch (col) {
        case "characters": Model = Character; break;
        case "dreams": Model = Dream; break;
        case "events": Model = Event; break;
        case "objects": Model = ObjectModel; break;
        case "places": Model = Place; break;
        case "symbols": Model = Symbol; break;
      }

      const data = await Model.find({ $text: { $search: query } });
      if (data.length > 0) {
        results[col] = data;
      }
    }

    if (Object.keys(results).length === 0) {
      return res.status(404).json({ message: "No se encontró nada relacionado con tu pregunta." });
    }

    res.json(results);
  } catch (err) {
    console.error("Error searching:", err);
    res.status(500).json({ message: "Error interno del servidor al buscar." });
  }
});

module.exports = router;
