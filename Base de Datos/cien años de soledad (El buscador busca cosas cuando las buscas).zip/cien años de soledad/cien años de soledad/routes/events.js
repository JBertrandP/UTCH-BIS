const express = require('express');
const router = express.Router();
const Event = require('../models/Event');

// Obtener todos los eventos
router.get('/', async (req, res) => {
  try {
    const events = await Event.find()
      .populate('personajes')
      .populate('lugar')
      .populate('objetos')
      .populate('capitulo');
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Obtener un evento específico
router.get('/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate('personajes')
      .populate('lugar')
      .populate('objetos')
      .populate('capitulo');
    if (!event) return res.status(404).json({ message: 'Evento no encontrado' });
    res.json(event);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo evento
router.post('/', async (req, res) => {
  const event = new Event({
    evento: req.body.evento,
    descripcion: req.body.descripcion,
    personajes: req.body.personajes,
    lugar: req.body.lugar,
    objetos: req.body.objetos,
    capitulo: req.body.capitulo
  });

  try {
    const newEvent = await event.save();
    res.status(201).json(newEvent);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Actualizar evento
router.patch('/:id', async (req, res) => {
  try {
    const updatedEvent = await Event.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    )
    .populate('personajes')
    .populate('lugar')
    .populate('objetos')
    .populate('capitulo');
    if (!updatedEvent) return res.status(404).json({ message: 'Evento no encontrado' });
    res.json(updatedEvent);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Buscar eventos
router.get('/search/:term', async (req, res) => {
  try {
    const events = await Event.find({
      $or: [
        { evento: { $regex: req.params.term, $options: 'i' } },
        { descripcion: { $regex: req.params.term, $options: 'i' } }
      ]
    })
    .populate('personajes')
    .populate('lugar')
    .populate('objetos')
    .populate('capitulo');
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;