const express = require('express');
const router = express.Router();
const Symbol = require('../models/Symbol');

// Obtener todos los símbolos
router.get('/', async (req, res) => {
  try {
    const symbols = await Symbol.find().populate('capitulo');
    res.json(symbols);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Obtener un símbolo específico
router.get('/:id', async (req, res) => {
  try {
    const symbol = await Symbol.findById(req.params.id).populate('capitulo');
    if (!symbol) return res.status(404).json({ message: 'Símbolo no encontrado' });
    res.json(symbol);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo símbolo
router.post('/', async (req, res) => {
  const symbol = new Symbol({
    simbolo: req.body.simbolo,
    descripcion: req.body.descripcion,
    significado: req.body.significado,
    capitulo: req.body.capitulo
  });

  try {
    const newSymbol = await symbol.save();
    res.status(201).json(newSymbol);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Actualizar símbolo
router.patch('/:id', async (req, res) => {
  try {
    const updatedSymbol = await Symbol.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate('capitulo');
    if (!updatedSymbol) return res.status(404).json({ message: 'Símbolo no encontrado' });
    res.json(updatedSymbol);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Buscar símbolos
router.get('/search/:term', async (req, res) => {
  try {
    const symbols = await Symbol.find({
      $or: [
        { simbolo: { $regex: req.params.term, $options: 'i' } },
        { descripcion: { $regex: req.params.term, $options: 'i' } },
        { significado: { $regex: req.params.term, $options: 'i' } }
      ]
    }).populate('capitulo');
    res.json(symbols);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;