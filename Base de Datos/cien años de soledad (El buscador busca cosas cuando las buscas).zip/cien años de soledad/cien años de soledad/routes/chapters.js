const express = require('express');
const router = express.Router();
const Chapter = require('../models/Chapter');

// Obtener todos los capítulos
router.get('/', async (req, res) => {
  try {
    const chapters = await Chapter.find()
      .populate('eventos')
      .populate('sueños')
      .populate('simbolos');
    res.json(chapters);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Obtener un capítulo específico
router.get('/:id', async (req, res) => {
  try {
    const chapter = await Chapter.findById(req.params.id)
      .populate('eventos')
      .populate('sueños')
      .populate('simbolos');
    if (!chapter) return res.status(404).json({ message: 'Capítulo no encontrado' });
    res.json(chapter);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo capítulo
router.post('/', async (req, res) => {
  const chapter = new Chapter({
    eventos: req.body.eventos,
    sueños: req.body.sueños,
    simbolos: req.body.simbolos
  });

  try {
    const newChapter = await chapter.save();
    res.status(201).json(newChapter);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Actualizar capítulo
router.patch('/:id', async (req, res) => {
  try {
    const updatedChapter = await Chapter.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate('eventos sueños simbolos');
    if (!updatedChapter) return res.status(404).json({ message: 'Capítulo no encontrado' });
    res.json(updatedChapter);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Buscar capítulos relacionados
router.get('/search/:term', async (req, res) => {
  try {
    const chapters = await Chapter.find()
      .populate({
        path: 'eventos',
        match: { evento: { $regex: req.params.term, $options: 'i' } }
      })
      .populate({
        path: 'sueños',
        match: { sueño: { $regex: req.params.term, $options: 'i' } }
      })
      .populate({
        path: 'simbolos',
        match: { simbolo: { $regex: req.params.term, $options: 'i' } }
      });
    
    res.json(chapters.filter(ch => 
      ch.eventos.length > 0 || 
      ch.sueños.length > 0 || 
      ch.simbolos.length > 0
    ));
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;