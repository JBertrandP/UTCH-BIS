const express = require('express');
const router = express.Router();
const Dream = require('../models/Dream');

// Obtener todos los sueños
router.get('/', async (req, res) => {
  try {
    const dreams = await Dream.find().populate('personaje capitulo');
    res.json(dreams);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Obtener un sueño específico
router.get('/:id', async (req, res) => {
  try {
    const dream = await Dream.findById(req.params.id).populate('personaje capitulo');
    if (!dream) return res.status(404).json({ message: 'Sueño no encontrado' });
    res.json(dream);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Crear nuevo sueño
router.post('/', async (req, res) => {
  const dream = new Dream({
    sueño: req.body.sueño,
    personaje: req.body.personaje,
    descripcion: req.body.descripcion,
    significado: req.body.significado,
    capitulo: req.body.capitulo
  });

  try {
    const newDream = await dream.save();
    res.status(201).json(newDream);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Actualizar sueño
router.patch('/:id', async (req, res) => {
  try {
    const updatedDream = await Dream.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).populate('personaje capitulo');
    if (!updatedDream) return res.status(404).json({ message: 'Sueño no encontrado' });
    res.json(updatedDream);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Buscar sueños
router.get('/search/:term', async (req, res) => {
  try {
    const dreams = await Dream.find({
      $or: [
        { sueño: { $regex: req.params.term, $options: 'i' } },
        { descripcion: { $regex: req.params.term, $options: 'i' } },
        { significado: { $regex: req.params.term, $options: 'i' } }
      ]
    }).populate('personaje capitulo');
    res.json(dreams);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;