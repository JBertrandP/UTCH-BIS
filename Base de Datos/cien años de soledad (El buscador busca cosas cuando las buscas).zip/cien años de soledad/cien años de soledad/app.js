const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");

// Load environment variables
dotenv.config();

// Initialize app
const app = express();

// Database connection
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000, // Tiempo de espera para conexión
      socketTimeoutMS: 45000 // Tiempo de espera para operaciones
    });
    console.log(`MongoDB Connected: ${mongoose.connection.host}`);
    
    // Verificación adicional de conexión
    mongoose.connection.on('connected', () => {
      console.log('Mongoose connected to DB');
    });
    
    mongoose.connection.on('error', (err) => {
      console.error('Mongoose connection error:', err);
    });
  } catch (err) {
    console.error("Database connection error:", err.message);
    process.exit(1);
  }
};

// Middleware
app.use(cors());
app.use(express.json());

// Añade esto en tu app.js antes de las otras rutas
app.get('/api/db-info', (req, res) => {
    res.json({
        dbName: mongoose.connection.db.databaseName,
        dbHost: mongoose.connection.host,
        collections: mongoose.connection.collections,
        readyState: mongoose.connection.readyState // 1 = conectado
    });
});

// Route imports
app.use('/api/chapters', require('./routes/chapters'));
app.use('/api/characters', require('./routes/characters'));
app.use('/api/dreams', require('./routes/dreams'));
app.use('/api/events', require('./routes/events'));
app.use('/api/objects', require('./routes/objects'));
app.use('/api/places', require('./routes/places'));
app.use('/api/symbols', require('./routes/symbols'));
app.use("/api/ask", require("./routes/ask"));


// Base route
app.get("/", (req, res) => {
  res.send("API de Cien Años de Soledad - Operativa");
});

// Health check endpoint
app.get('/health', (req, res) => {
  const dbStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
  res.json({
    status: 'UP',
    database: dbStatus,
    timestamp: new Date()
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Se petateo' });
});

// Start server
const PORT = process.env.PORT || 3000;

const startServer = async () => {
  await connectDB();
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'probanding'}`);
    console.log(`Database: ${mongoose.connection.name}`);
  });
};

startServer();