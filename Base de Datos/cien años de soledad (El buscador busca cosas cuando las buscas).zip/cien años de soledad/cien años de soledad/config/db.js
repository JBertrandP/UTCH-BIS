const mongoose = require("mongoose");
require("dotenv").config();

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 5000, // Esperar 5 segundos antes de fallar
            socketTimeoutMS: 45000, // Cerrar sockets después de 45 segundos de inactividad
            dbName: '100_years_of_loneliness' // Especifica explícitamente el nombre de tu base de datos
        });
        
        console.log(`MongoDB connected to: ${mongoose.connection.host}`);
        console.log(`Database name: ${mongoose.connection.db.databaseName}`);
        
    } catch (error) {
        console.error("MongoDB connection failed:", error.message);
        process.exit(1); 
    }
};

module.exports = connectDB;