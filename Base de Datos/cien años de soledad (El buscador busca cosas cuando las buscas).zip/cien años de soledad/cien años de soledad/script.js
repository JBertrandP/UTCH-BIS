const baseURL = "http://localhost:3000/api";

// ========== 1. Buscador General ==========
const searchForm = document.querySelector(".idk");
if (searchForm) {
  searchForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const input = document.querySelector(".buscador");
    if (input && input.value.trim() !== "") {
      window.location.href = `respuesta.html?q=${encodeURIComponent(input.value.trim())}`;
    }
  });
}

// ========== 2. Mostrar resultados en respuesta.html ==========

if (window.location.pathname.includes("respuesta.html")) {
  document.addEventListener("DOMContentLoaded", async () => {
    const query = new URLSearchParams(window.location.search).get("q");
    const resultBox = document.getElementById("resultBox");
    const capMatch = query?.match(/^capitulo-(\d{1,2})$/);

    if (capMatch) {
      const chapterNum = parseInt(capMatch[1]);

      try {
        const res = await fetch(`${baseURL}/chapters/number/${chapterNum}`);
        const chapter = await res.json();

        if (!res.ok || !chapter) {
          resultBox.innerHTML = `<h5>Capítulo no encontrado</h5>`;
          return;
        }

        resultBox.innerHTML = `<h4 class="mt-2">Contenido del Capítulo ${chapterNum}</h4>`;

        if (chapter.eventos?.length > 0) {
          resultBox.innerHTML += `<h5 class="mt-3">Eventos</h5><ul class="list-group mb-3">`;
          chapter.eventos.forEach(e => {
            resultBox.innerHTML += `<li class="list-group-item"><strong>${e.evento}</strong> - ${e.descripcion}</li>`;
          });
          resultBox.innerHTML += `</ul>`;
        }

        if (chapter.sueños?.length > 0) {
          resultBox.innerHTML += `<h5>Sueños</h5><ul class="list-group mb-3">`;
          chapter.sueños.forEach(s => {
            resultBox.innerHTML += `<li class="list-group-item"><strong>${s.sueño}</strong> - ${s.descripcion}</li>`;
          });
          resultBox.innerHTML += `</ul>`;
        }

        if (chapter.simbolos?.length > 0) {
          resultBox.innerHTML += `<h5>Símbolos</h5><ul class="list-group mb-3">`;
          chapter.simbolos.forEach(sym => {
            resultBox.innerHTML += `<li class="list-group-item"><strong>${sym.simbolo}</strong> - ${sym.descripcion} (${sym.significado || "Sin significado"})</li>`;
          });
          resultBox.innerHTML += `</ul>`;
        }

      } catch (error) {
        resultBox.innerHTML = `<h5>Error</h5><p>${error.message}</p>`;
      }

      return;
    }

    if (!query || !resultBox) return;

    // ==== NUEVO: Si contiene ?, busca por pregunta en /api/ask ====
    if (query.includes("?")) {
      try {
        const res = await fetch(`${baseURL}/ask?q=${encodeURIComponent(query)}`);
        const data = await res.json();

        let found = false;
        let resultsHTML = "";

        const sections = {
          characters: "Personajes",
          dreams: "Sueños",
          events: "Eventos",
          objects: "Objetos",
          places: "Lugares",
          symbols: "Símbolos"
        };

        for (const key in sections) {
          const items = data[key];
          if (items && items.length > 0) {
            found = true;
            resultsHTML += `<h5 class='card-title mt-3'>${sections[key]}</h5><ul class='list-group mb-3'>`;

            items.forEach(item => {
              switch (key) {
                case "characters":
                  resultsHTML += `<li class='list-group-item'><strong>${item.nombre}</strong> - Generación: ${item.generacion || "N/A"}</li>`;
                  break;
                case "dreams":
                  resultsHTML += `<li class='list-group-item'><strong>${item.sueño}</strong> - ${item.descripcion} (${item.personaje?.nombre || "Sin personaje"})</li>`;
                  break;
                case "events":
                  resultsHTML += `<li class='list-group-item'><strong>${item.evento}</strong> - ${item.descripcion}</li>`;
                  break;
                case "objects":
                  resultsHTML += `<li class='list-group-item'><strong>${item.nombre}</strong> - ${item.descripcion} (Dueño: ${item.dueño?.nombre || "Desconocido"})</li>`;
                  break;
                case "places":
                  resultsHTML += `<li class='list-group-item'><strong>${item.nombre}</strong> - ${item.descripcion || "Sin descripción"}</li>`;
                  break;
                case "symbols":
                  resultsHTML += `<li class='list-group-item'><strong>${item.simbolo}</strong> - ${item.descripcion} (${item.significado || "Sin significado"})</li>`;
                  break;
              }
            });

            resultsHTML += `</ul>`;
          }
        }

        resultBox.innerHTML = found ? resultsHTML : `<h5>No se encontraron resultados para la pregunta.</h5>`;
      } catch (err) {
        resultBox.innerHTML = `<h5>Error</h5><p>${err.message}</p>`;
      }

      return;
    }

    // === COMPORTAMIENTO ORIGINAL ===
    const collections = ["characters", "dreams", "events", "objects", "places", "symbols"];
    let resultsHTML = "";
    let found = false;

    Promise.all(collections.map(col =>
      fetch(`${baseURL}/${col}/search/${encodeURIComponent(query)}`)
        .then(res => res.ok ? res.json() : [])
        .then(data => ({ col, data }))
    ))
    .then(allResults => {
      allResults.forEach(({ col, data }) => {
        if (data && data.length > 0) {
          found = true;
          resultsHTML += `<h5 class='card-title text-capitalize'>${col}</h5><ul class='list-group mb-3'>`;

          data.forEach(item => {
            switch (col) {
              case "characters":
                resultsHTML += `<li class='list-group-item'><h4 class='card-subtitle'>${item.nombre}</h4>  <h4 class='card-text'>Generación: ${item.generacion || "N/A"}</h4></li>`;
                break;
              case "dreams":
                resultsHTML += `<li class='list-group-item'><h4 class='card-subtitle'>${item.sueño}</h4> <h4 class='card-text'>${item.descripcion} (${item.personaje?.nombre || "Sin personaje"})</h4></li>`;
                break;
              case "events":
                resultsHTML += `<li class='list-group-item'><h4 class='card-subtitle'>${item.evento}</h4>  <h4 class='card-text'>${item.descripcion}</h4></li>`;
                break;
              case "objects":
                resultsHTML += `<li class='list-group-item'><h4 class='card-subtitle'>${item.nombre}</h4>  <h4 class='card-text'>${item.descripcion} (Dueño: ${item.dueño})</h4></li>`;
                break;
              case "places":
                resultsHTML += `<li class='list-group-item'><h4 class='card-subtitle'>${item.nombre}</h4>  <h4 class='card-text'>${item.descripcion}</li>`;
                break;
              case "symbols":
                resultsHTML += `<li class='list-group-item'><h4 class='card-subtitle'>${item.simbolo}</h4> <h4 class='card-text'>${item.descripcion} (${item.significado || "Sin significado"})</h4></li>`;
                break;
            }
          });
          resultsHTML += `</ul>`;
        }
      });

      resultBox.innerHTML = found ? resultsHTML : `<h5 class='card-subtitle'>Sin resultados</h5><p class='card-text'>No se encontró información sobre "${query}".</p>`;
    })
    .catch(err => {
      resultBox.innerHTML = `<h5>Error</h5><p>${err.message}</p>`;
    });
  });
}

// ========== 3. Utilidades de conversión ==========
async function getIdByName(endpoint, name) {
  const res = await fetch(`${baseURL}/${endpoint}/search/${encodeURIComponent(name)}`);
  const data = await res.json();
  return data[0]?._id || null;
}

async function resolveIdsArray(endpoint, names) {
  const ids = [];
  for (let name of names) {
    const id = await getIdByName(endpoint, name);
    if (id) ids.push(id);
  }
  return ids;
}

// ========== 4. Inserciones desde los modales ==========
function setupAddForm(entity, fields) {
  const button = document.querySelector(`#modalC${capitalize(entity)} .btn`);
  const form = document.querySelector(`#modalC${capitalize(entity)} form`);

  if (button && form) {
    button.addEventListener("click", async () => {
      const data = {};
      const inputs = form.querySelectorAll("input");
      const values = [...inputs].map(i => i.value.trim());

      for (let i = 0; i < fields.length; i++) {
        if (inputs[i].hasAttribute("required") && values[i] === "") {
          return alert(`El campo '${fields[i]}' es obligatorio.`);
        }
        data[fields[i]] = values[i];
      }

      try {
        if (entity === "characters") {
          data.generacion = parseInt(data.generacion);
          if (data.pareja) data.pareja = await getIdByName("characters", data.pareja);
          if (data.hijos) data.hijos = await resolveIdsArray("characters", data.hijos.split(","));
        }

        if (entity === "dreams") {
          data.personaje = await getIdByName("characters", data.personaje);
          if (!data.personaje) return alert("Personaje no encontrado");
        }

        if (entity === "events") {
          data.personajes = await resolveIdsArray("characters", data.personajes.split(","));
          data.lugar = await getIdByName("places", data.lugar);
          data.objetos = await resolveIdsArray("objects", data.objetos.split(","));
        }

        const res = await fetch(`${baseURL}/${entity}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });

        if (!res.ok) {
          const error = await res.json();
          throw new Error(error.message || "Error al insertar");
        }

        alert(`${capitalize(entity)} agregado correctamente.`);
        form.reset();
      } catch (err) {
        alert("Error: " + err.message);
      }
    });
  }
}

// ========== 5. Ediciones desde los modales ==========
function setupEditForm(entity, fields) {
  const modal = document.querySelector(`#modalU${capitalize(entity)}`);
  const button = modal?.querySelector(".btn");
  const form = modal?.querySelector("form");

  if (!modal || !form || !button) return;

  let editingId = null;

  button.addEventListener("click", async () => {
    const inputs = form.querySelectorAll("input");
    const firstField = inputs[0];

    if (!editingId) {
      const name = firstField.value.trim();
      if (!name) return alert("Ingresa un nombre para buscar.");

      try {
        const res = await fetch(`${baseURL}/${entity}/search/${encodeURIComponent(name)}`);
        const data = await res.json();

        if (res.ok && data.length > 0) {
          const item = data[0];
          editingId = item._id;

          fields.forEach(field => {
            const input = form.querySelector(`[name="${field}"]`);
            if (input) {
              input.value = item[field] || "";
            }
          });

          alert("Elemento encontrado. Edita los datos y haz clic nuevamente para guardar los cambios.");
        } else {
          alert("Elemento no encontrado.");
        }
      } catch (err) {
        alert("Error al buscar: " + err.message);
      }

      return;
    }

    const data = {};
    fields.forEach(field => {
      const input = form.querySelector(`[name="${field}"]`);
      if (input) data[field] = input.value.trim();
    });

    if (entity === "characters") {
      data.generacion = parseInt(data.generacion);
      if (data.pareja) data.pareja = await getIdByName("characters", data.pareja);
      if (data.hijos) data.hijos = await resolveIdsArray("characters", data.hijos.split(","));
    }

    if (entity === "dreams") {
      data.personaje = await getIdByName("characters", data.personaje);
    }

    if (entity === "events") {
      data.personajes = await resolveIdsArray("characters", data.personajes.split(","));
      data.lugar = await getIdByName("places", data.lugar);
      data.objetos = await resolveIdsArray("objects", data.objetos.split(","));
    }

    try {
      const res = await fetch(`${baseURL}/${entity}/${editingId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });

      if (!res.ok) throw new Error("Error al actualizar");

      alert("Actualizado correctamente.");
      form.reset();
      editingId = null;
    } catch (err) {
      alert("Error al guardar: " + err.message);
    }
  });
}

// ========== 6. Utilidades ==========
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ========== 7. Registrar formularios ==========
setupAddForm("characters", ["nombre", "generacion", "pareja", "hijos"]);
setupAddForm("dreams", ["sueño", "personaje", "descripcion", "significado"]);
setupAddForm("events", ["evento", "descripcion", "personajes", "lugar", "objetos"]);
setupAddForm("objects", ["nombre", "descripcion", "dueno"]);
setupAddForm("places", ["nombre", "descripcion"]);
setupAddForm("symbols", ["simbolo", "descripcion", "significado"]);

setupEditForm("characters", ["nombre", "generacion", "pareja", "hijos"]);
setupEditForm("dreams", ["sueño", "personaje", "descripcion", "significado"]);
setupEditForm("events", ["evento", "descripcion", "personajes", "lugar", "objetos"]);
setupEditForm("objects", ["nombre", "descripcion", "dueno"]);
setupEditForm("places", ["nombre", "descripcion"]);
setupEditForm("symbols", ["simbolo", "descripcion", "significado"]);

document.querySelectorAll(".chapter").forEach(chapter => {
  chapter.addEventListener("click", () => {
    const num = chapter.getAttribute("data-capitulo");
    if (num) {
      window.location.href = `respuesta.html?q=capitulo-${num}`;
    }
  });
});
