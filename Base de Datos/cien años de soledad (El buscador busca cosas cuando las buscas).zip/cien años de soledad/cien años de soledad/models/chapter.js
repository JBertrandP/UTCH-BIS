const mongoose = require("mongoose");

const ChapterSchema = new mongoose.Schema({
  number: { type: Number, required: true, unique: true },
  title: { type: String },
  eventos: [{ type: mongoose.Schema.Types.ObjectId, ref: "Event" }],
  sueños: [{ type: mongoose.Schema.Types.ObjectId, ref: "Dream" }],
  simbolos: [{ type: mongoose.Schema.Types.ObjectId, ref: "Symbol" }]
}, { timestamps: true });

module.exports = mongoose.model("Chapter", ChapterSchema);