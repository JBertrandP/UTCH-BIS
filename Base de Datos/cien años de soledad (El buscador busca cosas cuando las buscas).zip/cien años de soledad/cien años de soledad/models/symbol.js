const mongoose = require("mongoose");

const SymbolSchema = new mongoose.Schema({
  simbolo: { type: String, required: true, unique: true },
  descripcion: { type: String, required: true },
  significado: { type: String, required: true },
  capitulo: { type: mongoose.Schema.Types.ObjectId, ref: "Chapter" }
}, { timestamps: true });

module.exports = mongoose.model("Symbol", SymbolSchema);