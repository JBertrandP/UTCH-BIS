const mongoose = require("mongoose");

const PlaceSchema = new mongoose.Schema({
  nombre: { type: String, required: true, unique: true },
  descripcion: { type: String },
  importancia: { type: String }
}, { timestamps: true });

module.exports = mongoose.model("Place", PlaceSchema);