const mongoose = require("mongoose");

const CharacterSchema = new mongoose.Schema({
  nombre: { type: String, required: true, unique: true },
  generacion: { type: Number, required: true, min: 1, max: 7 },
  pareja: { type: mongoose.Schema.Types.ObjectId, ref: "Character" },
  hijos: [{ type: mongoose.Schema.Types.ObjectId, ref: "Character" }],
  descripcion: { type: String }
}, { timestamps: true });

module.exports = mongoose.model("Character", CharacterSchema);