const mongoose = require("mongoose");

const EventSchema = new mongoose.Schema({
  evento: { type: String, required: true },
  descripcion: { type: String, required: true },
  personajes: [{ type: mongoose.Schema.Types.ObjectId, ref: "Character" }],
  lugar: { type: mongoose.Schema.Types.ObjectId, ref: "Place" },
  objetos: [{ type: mongoose.Schema.Types.ObjectId, ref: "Object" }],
  capitulo: { type: mongoose.Schema.Types.ObjectId, ref: "Chapter" }
}, { timestamps: true });

module.exports = mongoose.model("Event", EventSchema);