const mongoose = require("mongoose");

const DreamSchema = new mongoose.Schema({
  sueño: { type: String, required: true },
  personaje: { type: mongoose.Schema.Types.ObjectId, ref: "Character", required: true },
  descripcion: { type: String, required: true },
  significado: { type: String },
  capitulo: { type: mongoose.Schema.Types.ObjectId, ref: "Chapter" }
}, { timestamps: true });

module.exports = mongoose.model("Dream", DreamSchema);
