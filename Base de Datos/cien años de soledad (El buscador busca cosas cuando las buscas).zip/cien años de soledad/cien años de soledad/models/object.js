const mongoose = require("mongoose");

const ObjectSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  descripcion: { type: String },
  dueño: { type: mongoose.Schema.Types.ObjectId, ref: "Character" },
  simbolismo: { type: String }
}, { timestamps: true });

module.exports = mongoose.model("Object", ObjectSchema);